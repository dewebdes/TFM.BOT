window.returnTitle = function() {
  return document.title;
};

